const AWS = require('aws-sdk');
	  AWS.config.update({region:process.env.REGION});
const ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});
const rekognition = new AWS.Rekognition();
const s3 = new AWS.S3();
var s3keys = new Array();
var faceids = new Array();

exports.handler = function(event, context, callback) {
    
    function delete_collection(collectionid) {
		//delete collection
		var params = {
		  CollectionId: collectionid
		 };
		 
		 rekognition.deleteCollection(params, function(err, data) {
		   if (err) {
				console.log(err, err.stack); // an error occurred
				deleteDynamoDB();				
				callback(null,{
        	        statusCode: 200,
                    headers: {
                        "Access-Control-Allow-Origin" : "*",
                        "Access-Control-Allow-Credentials" : true
                    },
                    body: JSON.stringify("couldn't delete collection "+params.CollectionId)
        	    });
		   }
		   else {
			   console.log("deleted collection "+collectionid);
			   deleteDynamoDB();
			   callback(null,{
        	        statusCode: 200,
                    headers: {
                        "Access-Control-Allow-Origin" : "*",
                        "Access-Control-Allow-Credentials" : true
                    },
                    body: JSON.stringify(collectionid)
        	    });
			}
		 });
    }
    
    function deleteDynamoDB() {
    	var iterator = 0;
	    var params = {
	        TableName: process.env.DYNAMODBTABLE
	    };
	    ddb.scan(params, function(err, data) {
	        if (err) {
	        	console.log(err, err.stack); // an error occurred
	        	deleteAllS3Objects(s3keys);
	        }
	        else {
	           
	            if(data.Count > 0) {
	                data.Items.forEach(function(element, index, array) {
	                    //console.log(element);
	                    let s3key = element.s3key;
	                    let faceid = element.faceid;
	                   
	                    console.log(s3key.S+" | "+faceid.S);
	                   
	                    let tmparray = new Array();
	                    tmparray = {"Key": s3key.S};
	                    s3keys.push(tmparray);
	                    //console.log(s3keys);
	                    var paramsdelete = {
	                        TableName: process.env.DYNAMODBTABLE,
	                        Key:{
	                            "faceid": faceid
	                        }
	                    };
	                    ddb.deleteItem(paramsdelete, function(errdelete, datadb){
	                        if(errdelete) {
	                            console.log(errdelete); 
	                        } else {
	                           
	                        }
	                        
	                        ++iterator;
	                        if(iterator === array.length) {
	                            deleteAllS3Objects(s3keys);
	                        }
	                    });
	
	                });
	            } else {
	            	deleteAllS3Objects(s3keys);
	            }
	        }
	    });
    }
    function deleteAllS3Objects(s3keys) {
    	console.log(s3keys);
        if(s3keys.length > 0) {
            
            var params = {
                Bucket: process.env.SOURCEBUCKET,
                Delete: {
                    Objects: s3keys
                }
            };
            s3.deleteObjects(params, function(err, data) {
                if(err) {
                    console.log(err);
                } else {
                	console.log("Delete objects from S3 successful.");
                	callback(null,{
	        	        statusCode: 200,
	                    headers: {
	                        "Access-Control-Allow-Origin" : "*",
	                        "Access-Control-Allow-Credentials" : true
	                    },
	                    body: JSON.stringify("Delete objects from S3 successful.")
	        	    });
                }
            });
            
        }
    }
    

    rekognition.listCollections({}, function(err, data) {
		if (err) {
			console.log(err, err.stack); // an error occurred
			callback(null,{
    	        statusCode: 200,
                headers: {
                    "Access-Control-Allow-Origin" : "*",
                    "Access-Control-Allow-Credentials" : true
                },
                body: JSON.stringify("Couldn't list collections")
    	    });
		}
		else {
			var collections = data.CollectionIds;
			
			if(collections.length > 0) {
				
				console.log("Collections: "+JSON.stringify(collections));
				
				collections.forEach(function(element, index, array){
				
					//get all faces in collection
					var paramsList = {
					 CollectionId: element	
					};
					rekognition.listFaces(paramsList, function(listerr, listdata) {
						if (listerr) {
							console.log("No faces in collection: "+listerr, listerr.stack); // an error occurred
							callback(null,{
			        	        statusCode: 200,
			                    headers: {
			                        "Access-Control-Allow-Origin" : "*",
			                        "Access-Control-Allow-Credentials" : true
			                    },
			                    body: JSON.stringify("no faces in collection")
			        	    });
						}
						else {
							var facecount = listdata.Faces.length;
							var iterator = 0;
							listdata.Faces.forEach(function(felement, findex, farray){
								
								var paramsdf = {
								  CollectionId: element, 
								  FaceIds: [
								    felement.FaceId
								  ]
								 };
								 rekognition.deleteFaces(paramsdf, function(dferr, dfdata) {
								   if (dferr) console.log(dferr, dferr.stack); // an error occurred
								   else {
									console.log(JSON.stringify(dfdata));
								   }
								 });
								 ++iterator;
								 if(iterator === facecount) {
									delete_collection(element);
								 }
							});
							
						
						
						}
					});
					
					
				});
			} else {
				// no collections
				console.log("No collections found.");
				deleteDynamoDB();
				callback(null,{
        	        statusCode: 200,
                    headers: {
                        "Access-Control-Allow-Origin" : "*",
                        "Access-Control-Allow-Credentials" : true
                    },
                    body: JSON.stringify("No collections found.")
        	    });
			}
			
				
		}
	 });
 
};
