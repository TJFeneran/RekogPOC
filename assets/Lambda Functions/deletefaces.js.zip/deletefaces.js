const AWS = require('aws-sdk');
const rekognition = new AWS.Rekognition();
const s3 = new AWS.S3();
const ddb = new AWS.DynamoDB.DocumentClient();
const collection = "rekog-custom-collection";

exports.handler = (event, context, callback) => {
	
	var faceids = new Array;
	faceids.push(event["queryStringParameters"]['faceid']);
	
	var rekparams = {
		CollectionId: collection,
		FaceIds: faceids
	};
	
	try {
		rekognition.deleteFaces(rekparams, function(err, rekdata) {
			
			if(err) {
				console.log(err, err.stack);
				const response = {
					statusCode: 200,
					headers: {
						"Access-Control-Allow-Origin" : "*",
						"Access-Control-Allow-Credentials" : true
					},
					body: "Could not delete faceIds: "+JSON.stringify(faceids)
				};
				callback(null,response);
			} else {
				console.log(JSON.stringify(rekdata));
	
				//remove item from DynamoDB
				var params = {
					TableName: process.env.DYNAMODBTABLE,
					Key:{
						"faceid": event["queryStringParameters"]['faceid']
					}
				};
	
				ddb.delete(params, function(err, ddbdata) {
					if (err) {
						console.error("Unable to delete item. Error JSON:", JSON.stringify(err, null, 2));
						callback("Couldn't delete item from DynamoDB");
					} else {
						
						//remove src s3 image
						var s3params = {
							Bucket: process.env.SRCBUCKET, 
							Key: event["queryStringParameters"]["s3key"]
						};

						s3.deleteObject(s3params, function(err, s3data) {
							if (err) console.log(err, err.stack);
							else {
								console.log(s3data);
								
								console.log("DeleteItem succeeded:", JSON.stringify(ddbdata, null, 2));
		
								const response = {
									statusCode: 200,
									headers: {
										"Access-Control-Allow-Origin" : "*",
										"Access-Control-Allow-Credentials" : true
									},
									body: JSON.stringify("success")
								};
							
								callback(null,response);
							}	
						});
						
					}
				});
			}
		});
	} catch (e) {
		console.log(e);
		const response = {
			statusCode: 200,
			headers: {
				"Access-Control-Allow-Origin" : "*",
				"Access-Control-Allow-Credentials" : true
			},
			body: "Malformed deleteFaces request. "+JSON.stringify(e)
		};
	
		callback(null,response);
	}

};
