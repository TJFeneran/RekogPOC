const AWS = require('aws-sdk');
const ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});

exports.handler = (event, context, callback) => {
	
	/*** Get all people using DynamoDB table scan ***/
	var params = {
		TableName: process.env.DYNAMODBTABLE
	};
	
	ddb.scan(params, function(err, data) {
		if (err) {
			console.log("Error", err);
			callback("Couldn't scan DynamoDB table.");
		} else {
	
			// empty name ternary
			for(var i in data.Items) {
				data.Items[i].personName = typeof data.Items[i].personName !== "undefined" ? data.Items[i].personName.S : "";
			}
			
//			console.log(data.Items);
			data.Items.sort((a, b) => (a.personName > b.personName) ? 1 : -1);
			
			//return items
			const response = {
				statusCode: 200,
				headers: {
					"Access-Control-Allow-Origin" : "*",
					"Access-Control-Allow-Credentials" : true
				},
				body: JSON.stringify(data.Items)
			};

			callback(null,response);
		}
	});

};