const AWS = require('aws-sdk');
const s3 = new AWS.S3();
const multipart = require('parse-multipart');

exports.handler = (event, context, callback) => {

    var eventbody = event.body;
    let buff = new Buffer(eventbody, 'base64');
    var boundarysplit = event.headers["content-type"].split("boundary=");
    var parts = multipart.Parse(buff,boundarysplit[1]);
    var filename = parts[0].filename;
        filename = filename.replace(/ /g, '');
        filename = filename.replace(/_/g, '');
        filename = filename.replace(/_/g, '');
        filename = filename.replace(/\'/g, '');
        
    console.log(boundarysplit[1]);
    console.log(parts[0]);
    console.log(parts[0].data);

    if(eventbody) { 
        //ToDo: add some logic here, make sure it's an image, etc
    
        var s3params = {
            Body: parts[0].data,
            Bucket: process.env.SOURCEBUCKET,
            Key: filename,
            ContentType: "image/jpeg"
        };
        
        s3.putObject(s3params, function(err,res){
           if(err) {

        	    callback(null,{
        	        statusCode: 200,
                    headers: {
                        "Access-Control-Allow-Origin" : "*",
                        "Access-Control-Allow-Credentials" : true
                    },
                    body: JSON.stringify(err)
        	    });
           } else {
               
               //upload successful
        
                callback(null,{
                    statusCode: 200,
                    headers: {
                        "Access-Control-Allow-Origin" : "*",
                        "Access-Control-Allow-Credentials" : true
                    },
                    body: JSON.stringify(res)
                });
               
           }
        });
    }

    
};
