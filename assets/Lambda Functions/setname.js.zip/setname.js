const AWS = require('aws-sdk');
const ddb = new AWS.DynamoDB.DocumentClient();
const ddbtable = process.env.DYNAMODBTABLE;

exports.handler = (event, context, callback) => {
	
	var faceid = event["queryStringParameters"]['faceid'];
	var personName = event["queryStringParameters"]["name"];
	
	if(faceid) {
		if(faceid.length > 15) {
	
			var ddbparams =  {};
	
			if(personName.length > 0) {
	
				ddbparams = {
					TableName: ddbtable,
					Key:{
						"faceid": faceid
					},
					UpdateExpression: "set personName = :n",
					ExpressionAttributeValues:{
						":n":personName
					},
					ReturnValues:"UPDATED_NEW"
				};
		
			} else {
	
				ddbparams = {
					TableName: ddbtable,
					Key:{
						"faceid": faceid
					},
					UpdateExpression: "REMOVE personName",
					ReturnValues:"ALL_NEW"
				};
	
			}
	
	
			ddb.update(ddbparams, function(err, data) {
				if (err) {
					console.error("Unable to update item. Error JSON:", JSON.stringify(err, null, 2));
					callback("Unable to update the item.");
				} else {
					console.log("UpdateItem succeeded:", JSON.stringify(data, null, 2));
					const response = {
						statusCode: 200,
						headers: {
							"Access-Control-Allow-Origin" : "*",
							"Access-Control-Allow-Credentials" : true
						},
						body: JSON.stringify("success")
					};
	
					callback(null,response);
				}
			});
	
		}
	}
	
};
