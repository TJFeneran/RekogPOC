const AWS = require('aws-sdk');
	  AWS.config.update({region:process.env.REGION});
	  
const rekognition = new AWS.Rekognition();
const ddb = new AWS.DynamoDB.DocumentClient({region: process.env.REGION});
const collection = "rekog-custom-collection";
const confidence_threshold = process.env.CONFIDENCE_THRESHOLD;
const inputvideo = "sampleVideo.mp4";

async function addDDBRow(jobid) {
	console.log("Adding entry to DynamoDB Tests table...");
	var params = {
		TableName : process.env.DDBTESTTABLE,
		Item: {
			jobid: jobid,
			status: "In Progress"
		}
	};
	let rowadded = false;
	const result = await ddb.put(params, function(err, data) {
		if (err) {
			console.log("Couldn't add row to tests table.");
			console.log(err);
			rowadded = false;
		}
		else {
			console.log("Row added successfully.");
			rowadded = true;
		}
	}).promise();
	return rowadded;
}

async function startSearch() {
	console.log("Starting seach function..");
	var paramsSearch = {
	    ClientRequestToken: process.env.RANDOMSTR,
		CollectionId: collection,
		FaceMatchThreshold: confidence_threshold,
		JobTag: "RekVideoTest",
		Video: {
		    S3Object: {
		        Bucket: process.env.UIBUCKET,
		        Name: inputvideo
		    }
		}
	};
	
	let jobid = null;
	const result = await rekognition.startFaceSearch(paramsSearch, function(err,data) {
	   if(err) {
	       console.log("Can't start face search in video.");
	       console.log(err);
	   } else {
		   console.log("Job started. JobId: "+data.JobId);
	       jobid = data.JobId;
	   }
	}).promise();
	return jobid;
}

async function checkDDB() {
	console.log("Checking DDB for entry in tests table...");
	var params = {
	  TableName: process.env.DDBTESTTABLE,
	  Limit: 1
	};
	const result = await ddb.scan(params).promise();
	return (result.Count > 0) ? true : false;
}


exports.handler = async (event) => {

	// Check DynamoDB
	let doesExist = await(checkDDB());
	if(doesExist) { 
		//exists
		console.log("Item found.");
		
		//job is in progress or done
		const response = {
			statusCode: 200,
			headers: {
				"Access-Control-Allow-Origin" : "*",
				"Access-Control-Allow-Credentials" : true
			},
			body: JSON.stringify("exists_not_started")
		};
		return(null,response);
		
	} else { 
		//add new
		console.log("Table empty.");
		
		//start rekog job
		let jobid = await(startSearch());
		if(jobid) {
			
			//add new ddb entry
			let rowadded = await addDDBRow(jobid);
			if(rowadded) {
				const response = {
					statusCode: 200,
					headers: {
						"Access-Control-Allow-Origin" : "*",
						"Access-Control-Allow-Credentials" : true
					},
					body: JSON.stringify(jobid)
				};
				return(null,response);
			}	
		}
	}
	
};
