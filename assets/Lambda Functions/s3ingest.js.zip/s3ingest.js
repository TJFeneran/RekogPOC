const AWS = require('aws-sdk');
const ddb = new AWS.DynamoDB.DocumentClient({region: process.env.REGION});
const rekognition = new AWS.Rekognition();
const collection = "rekog-custom-collection";

exports.handler = (event, context, callback) => {


	var isCollectionFound = false;
	
	// INDEX A FACE [Add to custom collection and insert DynamoDB record
	function indexFace() {

		var srcBucket = event.Records[0].s3.bucket.name;
		var srcObject = event.Records[0].s3.object.key;
		var url = "https://"+srcBucket+".s3.amazonaws.com/"+srcObject;

		var paramsIndexFace = {
			CollectionId: collection,
			DetectionAttributes: [ ],
			ExternalImageId: srcObject,
			Image: {
				S3Object: {
					Bucket: srcBucket,
					Name: srcObject
				}
			}
		};

		rekognition.indexFaces(paramsIndexFace, function(err, dataIndex) {
			if(err) { 
				console.log(err, err.stack);
				callback("Error indexing face.");
			}
			else {

				let newFaceId = dataIndex.FaceRecords[0].Face.FaceId;

				// INSERT INTO DynamoDB
				var paramsDDB = {
					TableName : process.env.DYNAMODBTABLE,
					Item: {
						faceid: newFaceId,
						imageURL: url,
						s3bucket: srcBucket,
						s3key: srcObject
					}
				};
				
				ddb.put(paramsDDB, function(err, data) {
					if (err) {
						console.log(err, err.stack);
						callback("Couldn't insert to DynamoDB");
					}
					else {
						console.log(data);
						callback(null, "Indexed Successfully");
					}
				});

			}
		});
	} 

	// LIST COLLECTIONS
	rekognition.listCollections( {} , function(err, data) {
		if(err) { 
			console.log(err, err.stack);
			callback("Could not list collections.");
		} else {
			if(data.CollectionIds.length > 0) {
				for(var i in data.CollectionIds) {
					if(data.CollectionIds[i] == collection) {
						isCollectionFound = true;
						break;
					}
				}
			}
			
			
			if(!isCollectionFound) {
				// CREATE COLLECTION 
				var params = {
					CollectionId: collection
				};
				
				rekognition.createCollection(params, function(err, data) {
					if (err) {
						console.log(err, err.stack);
						callback("Error creating collection '"+collection+"'");
					}
					else {
						console.log("Collection created: "+JSON.stringify(data));
						indexFace();
					}
				});
			} else {
				indexFace();
			}
	
		}
	}); 

};
